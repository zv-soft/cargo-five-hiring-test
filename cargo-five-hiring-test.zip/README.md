# cargo-five-hiring-test
Hiring Test

## Instalación

- Clonar el repositorio
- En la raíz del proyecto, crear archivo .env y copiar con código de env.example (no borrar el archivo env.example)
- Crear base de datos y poner datos de conexión en el archivo .env
- Abrir consola con la ubicación del proyecto.
- Comando: composer update
- Comando: npm install
- Comando: php artisan migrate --seed
- Comando: php artisan key:generate
- Comando: php artisan passport:install
- Comando: npm run watch (Correr en consola diferente cada vez que se inicie el proyecto.)
- Comando: php artisan serve (Correr en consola diferente cada vez que se inicie el proyecto.)
