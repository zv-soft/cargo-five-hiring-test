<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Auth extends Controller
{
    public function login(Request $request) { //Inicio de Sesión mediante Laravel Passport

        return $request;
    }
}
